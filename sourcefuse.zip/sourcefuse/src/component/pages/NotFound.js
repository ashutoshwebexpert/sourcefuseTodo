import React from 'react';

const NotFound = () =>{
    return(
        <div className="pnf">
            <h1>Page Not Found</h1>
        </div>
    )
}

export default NotFound;